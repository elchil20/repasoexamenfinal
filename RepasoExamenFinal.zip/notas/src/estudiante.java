import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class estudiante {
    private static final ArrayList<estudiante> lista = new ArrayList<>();
    String nombre;
    String asignatura;
    int notas;

    public estudiante(String nombre, String asignatura, int notas) {
        this.nombre = nombre;
        this.asignatura = asignatura;
        this.notas = notas;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getAsignatura() {
        return asignatura;
    }

    public void setAsignatura(String asignatura) {
        this.asignatura = asignatura;
    }

    public int getNotas() {
        return notas;
    }

    public void setNotas(int notas) {
        this.notas = notas;
    }

    @Override
    public String toString() {
        return nombre + ";" + asignatura + ";" + notas;
    }

    public static void insertestudiante() {
        int contador = 0;
        String nombre;
        String asignatura;
        int nota;
        Scanner sc = new Scanner(System.in);
        System.out.println("Dime el nombre del alumno al cual añadir las asignaturas y notas: ");
        nombre = sc.nextLine();
        System.out.println("Dime la asignatura: ");
        asignatura = sc.nextLine();
        do {
            System.out.println("Dime la nota: ");
            nota = sc.nextInt();
            lista.add(new estudiante(nombre, asignatura, nota));
            contador++;
        } while (contador < 10);
    }

    public static void exportarestudiante() throws IOException {
        Scanner sc = new Scanner(System.in);
        String nombrefichero;
        System.out.println("Dime la ruta del fichero nuevo y como quieres llamarlo: ");
        nombrefichero = sc.nextLine();
        BufferedWriter bw = new BufferedWriter(new FileWriter(nombrefichero));
        for (estudiante buscar : lista) {
            bw.write(String.valueOf(buscar));
            bw.newLine();
        }
        bw.close();
    }

    public static void promedioestudiante() {
        int notaTotal = 0;
        BufferedReader br = null;
        try {
            Scanner sc = new Scanner(System.in);
            String nombrefichero;
            System.out.println("Dime la ruta y el nombre del fichero a leer con su extension: ");
            nombrefichero = sc.nextLine();
            br = new BufferedReader(new FileReader(nombrefichero));
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes2 = linea.split(";");
                try {
                    notaTotal = notaTotal + Integer.parseInt(partes2[2]);
                } catch (NumberFormatException e){
                    System.out.println(" ");
                }

            }
            System.out.println(notaTotal);
            int notamedia = notaTotal/10;
            System.out.println(notamedia);
            System.out.println("El fichero ha sido recorrido correctamente");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (br != null)
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
        }
    }
}