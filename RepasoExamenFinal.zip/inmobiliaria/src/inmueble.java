import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class inmueble {

  private static final ArrayList<inmueble> listainmueble = new ArrayList<>();
    String direccion;
    String ciudad;
    String tipo;

    public inmueble(String direccion, String ciudad, String tipo) {
        this.direccion = direccion;
        this.ciudad = ciudad;
        this.tipo = tipo;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "Inmueble: " + direccion + " " + ciudad + " " + tipo;
    }
    public static void iniciales() {
        inmueble inmueble1 = new inmueble("Avenida1", "Elche", "arriendo");
        inmueble inmueble2 = new inmueble("Avenida2", "Alicante", "venta");
        inmueble inmueble3 = new inmueble("Avenida3", "Valencia", "venta");
        inmueble inmueble4 = new inmueble("Avenida4", "Madrid", "arriendo");
        listainmueble.add(inmueble1);
        listainmueble.add(inmueble2);
        listainmueble.add(inmueble3);
        listainmueble.add(inmueble4);

    }
    public static void addinnmueble() {
        Scanner sc = new Scanner(System.in);
        String direccion;
        String ciudad;
        String tipo;
        System.out.println("Dime la direccion del nuevo inmueble: ");
        direccion = sc.nextLine();
        System.out.println("Dime la ciudad del nuevo inmueble");
        ciudad = sc.nextLine();
        System.out.println("Dime el tipo de inmueble (arriendo o venta)");
        tipo = sc.nextLine();
        if (tipo.equalsIgnoreCase("Arriendo") || tipo.equalsIgnoreCase("Venta")) {
            listainmueble.add(new inmueble(direccion, ciudad, tipo));
        } else {
            System.out.println("No puedes poner algo diferente a arriendo o venta");
        }
    }
    public static void mostrarinnmuebles() {
        if (listainmueble.isEmpty()) {
            System.out.println("La lista de inmuebles esta vacia");
            System.out.println("Añadiendo inmuebles iniciales");
            inmueble.iniciales();
        } else {
            for (inmueble buscar : listainmueble) {
                System.out.println(buscar);
            }
        }
    }
    public static void editinnmuebles() {
        String direccion;
        Scanner sc = new Scanner(System.in);
        System.out.println("Dime la direccion del inmueble a cambiar: ");
        direccion = sc.nextLine();
        for (inmueble buscar : listainmueble) {
            if (buscar.getDireccion().equalsIgnoreCase(direccion)) {
                int indice = listainmueble.indexOf(buscar);
                String direccion2;
                System.out.println("Dime la direccion nueva");
                direccion2 = sc.nextLine();
                String ciudad;
                System.out.println("Dime la ciudad nueva");
                ciudad = sc.nextLine();
                String tipo;
                System.out.println("Dime el tipo nuevo");
                tipo = sc.nextLine();
                if (tipo.equalsIgnoreCase("Arriendo") || tipo.equalsIgnoreCase("Venta")) {
                    listainmueble.set(indice, (new inmueble(direccion2, ciudad, tipo)));
                } else {
                    System.out.println("No puedes poner algo diferente a arriendo o venta");
                }
            }
        }
    }
    public static void deleteinnmuebles() {
        String direccion;
        Scanner sc = new Scanner(System.in);
        System.out.println("Dime la direccion del inmueble a borrar: ");
        direccion = sc.nextLine();
        for (inmueble buscar : listainmueble) {
            if (buscar.getDireccion().equalsIgnoreCase(direccion)) {
                System.out.println(buscar);
                listainmueble.remove(buscar);
                break;
            }
        }
    }
    public static void exportarinnmuebles() throws IOException {
        Scanner sc = new Scanner(System.in);
        String nombrefichero;
        System.out.println("Dime la ruta del fichero nuevo y como quieres llamarlo: ");
        nombrefichero = sc.nextLine();
        BufferedWriter bw = new BufferedWriter(new FileWriter(nombrefichero));
        for (inmueble buscar : listainmueble) {
            bw.write(String.valueOf(buscar));
            bw.newLine();
        }
        bw.close();
        }
    }