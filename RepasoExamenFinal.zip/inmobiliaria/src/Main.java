import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {

    public static void menu() {
        System.out.println("===============================");
        System.out.println("0. Salir");
        System.out.println("1. Añadir inmuebles.");
        System.out.println("2. Editar inmuebles.");
        System.out.println("3. Eliminar inmuebles.");
        System.out.println("4. Exportar lista de inmuebles.");
        System.out.println("5. Mostrar lista de inmuebles.");
        System.out.println("===============================");
    }
    public static void main(String[] args) {
        boolean continuar = true;
        int opcion;
        while (continuar) {
            menu();
            System.out.println("Elige una opción: ");
            try {
                Scanner scanner = new Scanner(System.in);
                opcion = scanner.nextInt();
                scanner.nextLine();
                if (opcion < 0 || opcion > 5) {
                    System.out.println("Solo puedes poner un numero del 0-5");
                } else {
                    switch (opcion) {
                        case 0:
                            continuar = false;
                            System.out.println("Vuelve cuando quieras.");
                            break;
                        case 1:
                            inmueble.addinnmueble();
                            break;
                        case 2:
                            inmueble.editinnmuebles();
                            break;
                        case 3:
                            inmueble.deleteinnmuebles();
                            break;
                        case 4:
                            inmueble.exportarinnmuebles();
                            break;
                        case 5:
                            inmueble.mostrarinnmuebles();
                            break;
                    }
                }
            } catch (InputMismatchException a) {
                System.out.println("No puedes poner letras solo numeros del 0-5");
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }
}