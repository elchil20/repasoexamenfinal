import java.io.*;
import java.util.*;

public class lectura {
    private static final ArrayList<lectura> partes = new ArrayList<>();
    String parte0;
    String parte1;
    String parte2;
    String parte3;
    String parte4;
    String parte5;
    String parte6;

    public lectura(String parte0, String parte1, String parte2, String parte3, String parte4, String parte5, String parte6) {
        this.parte0 = parte0;
        this.parte1 = parte1;
        this.parte2 = parte2;
        this.parte3 = parte3;
        this.parte4 = parte4;
        this.parte5 = parte5;
        this.parte6 = parte6;
    }

    public String getParte0() {
        return parte0;
    }

    public void setParte0(String parte0) {
        this.parte0 = parte0;
    }

    public String getParte1() {
        return parte1;
    }

    public void setParte1(String parte1) {
        this.parte1 = parte1;
    }

    public String getParte2() {
        return parte2;
    }

    public void setParte2(String parte2) {
        this.parte2 = parte2;
    }

    public String getParte3() {
        return parte3;
    }

    public void setParte3(String parte3) {
        this.parte3 = parte3;
    }

    public String getParte4() {
        return parte4;
    }

    public void setParte4(String parte4) {
        this.parte4 = parte4;
    }

    public String getParte5() {
        return parte5;
    }

    public void setParte5(String parte5) {
        this.parte5 = parte5;
    }

    public String getParte6() {
        return parte6;
    }

    public void setParte6(String parte6) {
        this.parte6 = parte6;
    }

    @Override
    public String toString() {
        return parte0 + ";" + parte1 + ";" + parte2 + ";" + parte3 + ";" + parte4  + ";" + parte5  + ";" + parte6 + ";";
    }

    public static void lecturafichero() {
        BufferedReader br = null;
        try {
            Scanner sc = new Scanner(System.in);
            String nombrefichero;
            System.out.println("Dime la ruta y el nombre del fichero a leer con su extension: ");
            nombrefichero = sc.nextLine();
            br = new BufferedReader(new FileReader(nombrefichero));
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes2 = linea.split(";");
                String p0 = partes2[0];
                String p1 = partes2[1];
                String p2 = partes2[2];
                String p3 = partes2[3];
                String p4 = partes2[4];
                String p5 = partes2[5];
                String p6 = partes2[6];
                String nombre = p4.substring(p4.indexOf(",")+2);
                String apellido = p4.substring(0, p4.indexOf(","));
                String nombrecompleto = nombre + " " + apellido;
                partes.add(new lectura(p0, p1, p2, p3, nombrecompleto, p5, p6));
            }
            System.out.println("El fichero ha sido recorrido correctamente");
        } catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            if (br != null)
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
        }
    }
    public static void escriturafichero() throws IOException {
        Scanner sc = new Scanner(System.in);
        String nombrefichero;
        System.out.println("Dime la ruta del fichero nuevo y como quieres llamarlo: ");
        nombrefichero = sc.nextLine();
        BufferedWriter bw = new BufferedWriter(new FileWriter(nombrefichero));
        for (lectura parte : partes) {
            bw.write(String.valueOf(parte));
            bw.newLine();
        }
        bw.close();
    }
    public static void addparticipantes() throws IOException {
        Scanner sc = new Scanner(System.in);
        System.out.println("Vamos a añadir un participante nuevo.");
        String parte0, parte1, parte2, parte3, parte4, parte5, parte6;
        System.out.println("Dime la posicion del participante: ");
        parte0 = sc.nextLine();
        System.out.println("Dime el ranking del participante: ");
        parte1 = sc.nextLine();
        System.out.println("Dime el Club del participante: ");
        parte2 = sc.nextLine();
        System.out.println("Dime el genero del participante (m, f): ");
        parte3 = sc.nextLine();
        System.out.println("Dime el nombre del participante: ");
        parte4 = sc.nextLine();
        System.out.println("Dime el origen del participante: ");
        parte5 = sc.nextLine();
        System.out.println("Dime la puntuacion del participante: ");
        parte6 = sc.nextLine();
        partes.add(new lectura(parte0, parte1, parte2, parte3, parte4, parte5, parte6));
        System.out.println("Lista de participantes actualizada.");
    }

    public static void deleteparticipantes() throws IOException {
        if (partes.isEmpty()) {
            System.out.println("No hay participantes en la lista.");
        } else {
            String nombre;
            Scanner sc = new Scanner(System.in);
            System.out.println("Dime el participante que quieres borrar con su nombre.");
            nombre = sc.nextLine();
            for (lectura buscar : partes) {
                if (buscar.getParte4().equalsIgnoreCase(nombre)) {
                    partes.remove(buscar);
                    System.out.println("Participante borrado.");
                    System.out.println("Lista de participantes actualizada.");
                    break;
                }
            }
        }
    }

    public static void deleteparticipantes2() throws IOException {
        try {
            if (partes.isEmpty()) {
                System.out.println("No hay participantes en la lista.");
            } else {
                String respuesta;
                Scanner sc = new Scanner(System.in);
                System.out.println("Dime el campo por el que quieres borrar.");
                System.out.println("Posicion, Ranking, Club, Genero, Nombre, Origen, Puntuacion");
                respuesta = sc.nextLine();
                if (respuesta.equalsIgnoreCase("Posicion")) {
                    String posicion;
                    System.out.println("Dime la posicion del participante a borrar: ");
                    posicion = sc.nextLine();
                    System.out.println("Participante borrado.");
                    System.out.println("Lista de participantes actualizada.");
                    partes.removeIf(buscar -> buscar.getParte0().equalsIgnoreCase(posicion));

                } else if (respuesta.equalsIgnoreCase("Ranking")) {
                    String ranking;
                    System.out.println("Dime el ranking del participante a borrar: ");
                    ranking = sc.nextLine();
                    System.out.println("Participante borrado.");
                    System.out.println("Lista de participantes actualizada.");
                    partes.removeIf(buscar -> buscar.getParte1().equalsIgnoreCase(ranking));

                } else if (respuesta.equalsIgnoreCase("Club")) {
                    String club;
                    System.out.println("Dime el nombre del club a borrar: ");
                    club = sc.nextLine();
                    System.out.println("Participantes borrados.");
                    System.out.println("Lista de participantes actualizada.");
                    partes.removeIf(buscar -> buscar.getParte2().equalsIgnoreCase(club));

                } else if (respuesta.equalsIgnoreCase("Genero")) {
                    String genero;
                    System.out.println("Dime el genero a borrar: ");
                    genero = sc.nextLine();
                    System.out.println("Participantes borrados.");
                    System.out.println("Lista de participantes actualizada.");
                    partes.removeIf(buscar -> buscar.getParte3().equalsIgnoreCase(genero));

                } else if (respuesta.equalsIgnoreCase("Nombre")) {
                    String nombre;
                    System.out.println("Dime el nombre del participante a borrar: ");
                    nombre = sc.nextLine();
                    System.out.println("Participante borrado.");
                    System.out.println("Lista de participantes actualizada.");
                    partes.removeIf(buscar -> buscar.getParte4().equalsIgnoreCase(nombre));

                } else if (respuesta.equalsIgnoreCase("Origen")) {
                    String origen;
                    System.out.println("Dime el genero a borrar: ");
                    origen = sc.nextLine();
                    System.out.println("Participantes borrados.");
                    System.out.println("Lista de participantes actualizada.");
                    partes.removeIf(buscar -> buscar.getParte5().equalsIgnoreCase(origen));

                } else if (respuesta.equalsIgnoreCase("Puntuacion")) {
                    String punt;
                    System.out.println("Dime la puntuacion a borrar: ");
                    punt = sc.nextLine();
                    System.out.println("Participantes borrados.");
                    System.out.println("Lista de participantes actualizada.");
                    partes.removeIf(buscar -> buscar.getParte6().equalsIgnoreCase(punt));

                }
            }
        } catch (ConcurrentModificationException a) {
            System.out.println();
        }
    }


    public static void updateparticipantesTodo() throws IOException {
        if (partes.isEmpty()) {
            System.out.println("No hay participantes en la lista.");
        } else {
            String nombre;
            Scanner scan = new Scanner(System.in);
            System.out.println("Dime el participante que quieres actualizar con su nombre.");
            nombre = scan.nextLine();
            for (lectura buscar : partes) {
                if (buscar.getParte4().equalsIgnoreCase(nombre)) {
                    int indice = partes.indexOf(buscar);
                    Scanner sc = new Scanner(System.in);
                    System.out.println("Vamos a actualizar el participante.");
                    String parte0, parte1, parte2, parte3, parte4, parte5, parte6;
                    System.out.println("Dime la nueva posicion del participante.");
                    parte0 = sc.nextLine();
                    System.out.println("Dime el nuevo ranking del participante.");
                    parte1 = sc.nextLine();
                    System.out.println("Dime el nuevo Club del participante.");
                    parte2 = sc.nextLine();
                    System.out.println("Dime el nuevo genero del participante.");
                    parte3 = sc.nextLine();
                    System.out.println("Dime el nuevo nombre del participante (apellido + , + nombre).");
                    parte4 = sc.nextLine();
                    System.out.println("Dime el nuevo origen del participante.");
                    parte5 = sc.nextLine();
                    System.out.println("Dime la nueva puntuacion del participante.");
                    parte6 = sc.nextLine();
                    partes.set(indice,(new lectura(parte0, parte1, parte2, parte3, parte4, parte5, parte6)));
                    System.out.println("Lista de participantes actualizada.");
                    break;
                } else {
                    System.out.println("Ese participante no existe.");
                }
            }
        }
    }

    public static void updateparticipantes() throws IOException {
        if (partes.isEmpty()) {
            System.out.println("No hay participantes en la lista.");
        } else {
            String parte0, parte1, parte2, parte3, parte4, parte5, parte6;
            String nombre;
            String respuesta;
            Scanner scan = new Scanner(System.in);
            System.out.println("Dime el participante que quieres actualizar con su nombre.");
            nombre = scan.nextLine();
            for (lectura buscar : partes) {
                if (buscar.getParte4().equalsIgnoreCase(nombre)) {
                    int indice = partes.indexOf(buscar);
                    Scanner sc = new Scanner(System.in);
                    System.out.println("Dime que campo quieres actualizar?");
                    System.out.println("Posicion, Ranking, Club, Genero, Nombre, Origen, Puntuacion");
                    respuesta = sc.nextLine();
                    if (respuesta.equalsIgnoreCase("Posicion")) {
                        System.out.println("Dime la nueva posicion del participante.");
                        parte0 = sc.nextLine();
                        partes.set(indice, (new lectura(parte0, buscar.getParte1(), buscar.getParte2(),
                        buscar.getParte3(), buscar.getParte4(), buscar.getParte5(), buscar.getParte6())));
                        System.out.println("Participante actualizado.");
                    } else if (respuesta.equalsIgnoreCase("Ranking")) {
                        System.out.println("Dime el nuevo ranking del participante.");
                        parte1 = sc.nextLine();
                        partes.set(indice, (new lectura(buscar.getParte0(), parte1, buscar.getParte2(),
                        buscar.getParte3(), buscar.getParte4(), buscar.getParte5(), buscar.getParte6())));
                        System.out.println("Participante actualizado.");
                    }  else if (respuesta.equalsIgnoreCase("Club")) {
                        System.out.println("Dime el nuevo club del participante.");
                        parte2 = sc.nextLine();
                        partes.set(indice, (new lectura(buscar.getParte0(), buscar.getParte1(), parte2,
                        buscar.getParte3(), buscar.getParte4(), buscar.getParte5(), buscar.getParte6())));
                        System.out.println("Participante actualizado.");
                    }  else if (respuesta.equalsIgnoreCase("Genero")) {
                        System.out.println("Dime el nuevo genero del participante.");
                        parte3 = sc.nextLine();
                        partes.set(indice, (new lectura(buscar.getParte0(), buscar.getParte1(), buscar.getParte2(),
                        parte3, buscar.getParte4(), buscar.getParte5(), buscar.getParte6())));
                        System.out.println("Participante actualizado.");
                    }  else if (respuesta.equalsIgnoreCase("Nombre")) {
                        System.out.println("Dime el nuevo nombre del participante.");
                        parte4 = sc.nextLine();
                        partes.set(indice, (new lectura(buscar.getParte0(), buscar.getParte1(), buscar.getParte2(),
                        buscar.getParte3(), parte4, buscar.getParte5(), buscar.getParte6())));
                        System.out.println("Participante actualizado.");
                    }  else if (respuesta.equalsIgnoreCase("Origen")) {
                        System.out.println("Dime el nuevo origen del participante.");
                        parte5 = sc.nextLine();
                        partes.set(indice, (new lectura(buscar.getParte0(), buscar.getParte1(), buscar.getParte2(),
                        buscar.getParte3(), buscar.getParte4(), parte5, buscar.getParte6())));
                        System.out.println("Participante actualizado.");
                    }  else if (respuesta.equalsIgnoreCase("Puntuacion")) {
                        System.out.println("Dime la nueva puntuacion del participante.");
                        parte6 = sc.nextLine();
                        partes.set(indice, (new lectura(buscar.getParte0(), buscar.getParte1(), buscar.getParte2(),
                        buscar.getParte3(), buscar.getParte4(), buscar.getParte5(), parte6)));
                        System.out.println("Participante actualizado.");
                    }
                    break;
                }
            }
        }
    }

    public static void searchparticipantes() throws IOException {
        if (partes.isEmpty()) {
            System.out.println("No hay participantes en la lista.");
        } else {
            String nombre;
            Scanner sc = new Scanner(System.in);
            System.out.println("Dime el participante que quieres buscar con su nombre.");
            nombre = sc.nextLine();
            for (lectura buscar : partes) {
                if (buscar.getParte4().equalsIgnoreCase(nombre)) {
                    System.out.println(buscar);
                }
            }
        }
    }

    public static void searchparticipantes2() throws IOException {
        if (partes.isEmpty()) {
            System.out.println("No hay participantes en la lista.");
        } else {
            String respuesta;
            Scanner sc = new Scanner(System.in);
            System.out.println("Dime por que campo quieres buscar?");
            System.out.println("Posicion, Ranking, Club, Genero, Nombre, Origen, Puntuacion");
            respuesta = sc.nextLine();
                if (respuesta.equalsIgnoreCase("Posicion")) {
                    String posicion;
                    Scanner scan = new Scanner(System.in);
                    System.out.println("Dime la posicion a buscar: ");
                    posicion = scan.nextLine();
                    for (lectura buscar : partes) {
                        if (buscar.getParte0().equalsIgnoreCase(posicion)) {
                            System.out.println(buscar);
                        }
                    }
                } else if (respuesta.equalsIgnoreCase("Ranking")) {
                    String ranking;
                    Scanner scan = new Scanner(System.in);
                    System.out.println("Dime el ranking a buscar: ");
                    ranking = scan.nextLine();
                    for (lectura buscar : partes) {
                        if (buscar.getParte1().equalsIgnoreCase(ranking)) {
                            System.out.println(buscar);
                        }
                    }
                } else if (respuesta.equalsIgnoreCase("Club")) {
                    String club;
                    Scanner scan = new Scanner(System.in);
                    System.out.println("Dime el club a buscar: ");
                    club = scan.nextLine();
                    for (lectura buscar : partes) {
                        if (buscar.getParte2().equalsIgnoreCase(club)) {
                            System.out.println(buscar);
                        }
                    }
                } else if (respuesta.equalsIgnoreCase("Genero")) {
                    String genero;
                    Scanner scan = new Scanner(System.in);
                    System.out.println("Dime el genero a buscar: ");
                    genero = scan.nextLine();
                    for (lectura buscar : partes) {
                        if (buscar.getParte3().equalsIgnoreCase(genero)) {
                            System.out.println(buscar);
                        }
                    }
                } else if (respuesta.equalsIgnoreCase("Nombre")) {
                    String nombre;
                    Scanner scan = new Scanner(System.in);
                    System.out.println("Dime el nombre a buscar: ");
                    nombre = scan.nextLine();
                    for (lectura buscar : partes) {
                        if (buscar.getParte4().equalsIgnoreCase(nombre)) {
                            System.out.println(buscar);
                        }
                    }
                } else if (respuesta.equalsIgnoreCase("Origen")) {
                    String origen;
                    Scanner scan = new Scanner(System.in);
                    System.out.println("Dime el origen a buscar: ");
                    origen = scan.nextLine();
                    for (lectura buscar : partes) {
                        if (buscar.getParte5().equalsIgnoreCase(origen)) {
                            System.out.println(buscar);
                        }
                    }
                } else if (respuesta.equalsIgnoreCase("Puntuacion")) {
                    String punt;
                    Scanner scan = new Scanner(System.in);
                    System.out.println("Dime el nombre a buscar: ");
                    punt = scan.nextLine();
                    for (lectura buscar : partes) {
                        if (buscar.getParte6().equalsIgnoreCase(punt)) {
                            System.out.println(buscar);
                        }
                    }
                } else {
                    System.out.println("Ese campo no existe.");
                }
            }
        }

    public static void imprimirparticipantes() throws IOException {
        if (partes.isEmpty()) {
            System.out.println("La lista de participantes esta vacia.");
        } else {
            for (lectura parte : partes) {
                System.out.println(parte);
            }
        }
    }
}