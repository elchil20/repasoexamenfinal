import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {

    public static void menu() {
        System.out.println("===============================");
        System.out.println("0. Salir");
        System.out.println("1. Añadir Fichero inicial al Arraylist.");
        System.out.println("2. Exportar datos del Arraylist a txt.");
        System.out.println("3. Añadir participante.");
        System.out.println("4. Borrar participante por nombre.");
        System.out.println("5. Buscar participante por nombre.");
        System.out.println("6. Mostrar lista de participantes.");
        System.out.println("7. Actualizar todo de un participante por nombre.");
        System.out.println("8. Actualizar un participante por nombre y actualizar campo elegido.");
        System.out.println("9. Buscar participantes por campo elegido (Todas las concurrencias).");
        System.out.println("10. Borrar participantes por campo elegido (Todas las concurrencias).");
        System.out.println("===============================");
    }
    public static void main(String[] args) {
        boolean continuar = true;
        int opcion;
        while (continuar) {
            menu();
            System.out.println("Elige una opción: ");
            try {
                Scanner scanner = new Scanner(System.in);
                opcion = scanner.nextInt();
                scanner.nextLine();
                if (opcion < 0 || opcion > 10) {
                    System.out.println("Solo puedes poner un numero del 0-10");
                } else {
                    switch (opcion) {
                        case 0:
                            continuar = false;
                            System.out.println("Vuelve cuando quieras.");
                            break;
                        case 1:
                            lectura.lecturafichero();
                            break;
                        case 2:
                            lectura.escriturafichero();
                            break;
                        case 3:
                            lectura.addparticipantes();
                            break;
                        case 4:
                            lectura.deleteparticipantes();
                            break;
                        case 5:
                            lectura.searchparticipantes();
                            break;
                        case 6:
                            lectura.imprimirparticipantes();
                            break;
                        case 7:
                            lectura.updateparticipantesTodo();
                            break;
                        case 8:
                            lectura.updateparticipantes();
                            break;
                        case 9:
                            lectura.searchparticipantes2();
                            break;
                        case 10:
                           lectura.deleteparticipantes2();
                            break;
                    }
                }
            } catch (InputMismatchException | IOException a) {
                System.out.println("No puedes poner letras solo numeros del 0-10");
            }
        }
    }
}